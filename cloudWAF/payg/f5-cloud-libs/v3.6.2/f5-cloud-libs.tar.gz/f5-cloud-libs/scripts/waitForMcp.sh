#!/bin/bash

. $(dirname $0)/util.sh

wait_mcp_running
